# Snake by Rohan [![forthebadge](https://forthebadge.com/images/badges/made-with-python.svg)](https://forthebadge.com)
This Snake Game Is Made Using Python 3.6.5 & Pygame Module.
Hope You Will Like The Game.. and also u can use the code to make your own version of game.

> ### To play the game, simply double click on the **Snake.exe**.


Installing The Pygame Module:
<br>
* Open Terminal/CMD
* Type ```pip install pygame/ pip3 install pygame```

OR

* Open Terminal or CMD, then Type ```pip install -r <path to the game>```

**Example:** ```pip install -r c://Users/Downloads/SnakeByRohan/requirements.txt```

---

Dont Delete Any Files.. IT MAY CRASH THE GAME!

```Start The Game Using Snake.exe File!```


> **Cheats**
<br>
Press <b>Q</b> to add extra 10 points. :smile:

* Follow Me On Instagram at [RohanDasRD](https://www.instagram.com/RohanDasRD)
* Thanks to [Harsh Trivedi](https://harsh98trivedi.github.io) for creating this README

### ThankYou!
